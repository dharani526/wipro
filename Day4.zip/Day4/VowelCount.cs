// using System;
// class VowelCount
// {
//     static void Main()
//     {
//         Console.WriteLine("Enter you sentence:");
//         string s = Console.ReadLine();
//         int vowelCount = 0;
//         foreach (char ch in s)
//         {
//             if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
//             {
//                 vowelCount++;
//             }
//         }
//         Console.WriteLine("The count of vowels in the sentence is: " + vowelCount);
//     }
// }