// using System;
// class WordCount
// {
//     static void Main()
//     {
//         Console.WriteLine("Enter your sentence here: ");
//         string sentence = Console.ReadLine();
//         int wordCount = 0;
//         string[] splitSentence = sentence.Split(' ');
//         foreach (string words in splitSentence)
//         {
//             Console.WriteLine("The word is: " + words);
//             wordCount++;
//         }
//         Console.WriteLine("The words in the sentence are: " + wordCount);

//     }
// }