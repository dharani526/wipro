public interface IpaymentGateway
{
   
    //by default methods are abstract 
    void ProcessPayment();
    
}
