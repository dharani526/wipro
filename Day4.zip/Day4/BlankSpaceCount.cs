// using System;
// class BlankCount
// {
//     static void Main()
//     {
//         string sentence = "CSharp Language is invented in 2002";
//         int count = 0;
//         foreach(char ch in sentence)
//         {
//             if (ch == ' ')
//             {
//                 count++;
//             }
//         }
//         Console.WriteLine("The count of blank spaces are: " + count);
//     }
// }