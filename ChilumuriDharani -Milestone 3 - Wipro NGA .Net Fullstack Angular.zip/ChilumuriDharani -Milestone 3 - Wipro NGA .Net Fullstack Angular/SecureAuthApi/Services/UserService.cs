using SecureAuthAPI.Data;
using SecureAuthAPI.Models;
using BCrypt.Net;

namespace SecureAuthAPI.Services
{
    public class UserService
    {
        private readonly AppDbContext _context;

        public UserService(AppDbContext context)
        {
            _context = context;
        }

        public User Authenticate(string username, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == username);
            if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
                return null;
            return user;
        }

        public User OAuthAuthenticate(string provider, string token)
        {
            // Simulate Google validation
            if (provider.ToLower() == "google" && token == "oauth-access-token")
            {
                return new User { Id = 2, Username = "google_user", Role = "User" };
            }
            return null;
        }
    }
}
