using Microsoft.AspNetCore.Mvc;
using SecureAuthAPI.Models;
using SecureAuthAPI.Services;

namespace SecureAuthAPI.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : ControllerBase
    {
        private readonly UserService _userService;
        private readonly TokenService _tokenService;

        public AuthController(UserService userService, TokenService tokenService)
        {
            _userService = userService;
            _tokenService = tokenService;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest request)
        {
            var user = _userService.Authenticate(request.Username, request.Password);
            if (user == null)
                return Unauthorized(new { error = "Invalid username or password" });

            var token = _tokenService.GenerateToken(user);
            return Ok(new { token, expires_in = 3600, user = new { user.Id, user.Username, roles = new[] { user.Role } } });
        }

        [HttpPost("oauth")]
        public IActionResult OAuth([FromBody] OAuthRequest request)
        {
            var user = _userService.OAuthAuthenticate(request.Provider, request.Token);
            if (user == null)
                return Unauthorized(new { error = "OAuth authentication failed" });

            var token = _tokenService.GenerateToken(user);
            return Ok(new { token, expires_in = 3600, user = new { user.Id, user.Username, roles = new[] { user.Role } } });
        }
    }
}
