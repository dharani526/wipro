using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SecureAuthAPI.Controllers
{
    [ApiController]
    [Route("api/secure-data")]
    [Authorize]
    public class SecureDataController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetSecureData()
        {
            return Ok(new
            {
                message = "Secure data accessed successfully.",
                data = new { user_id = User.FindFirst("id")?.Value, secure_info = "This is some sensitive user data." }
            });
        }
    }
}
