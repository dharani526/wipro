using System.ComponentModel.DataAnnotations;

namespace SecureAuthAPI.Models
{
    public class OAuthRequest
    {
        [Required]
        public string Provider { get; set; }

        [Required]
        public string Token { get; set; }
    }
}
