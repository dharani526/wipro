using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using RoleAuthDemo.Models;

namespace RoleAuthDemo.Controllers
{
    public class AccountController : Controller
    {
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly UserManager<IdentityUser> _userManager;

        public AccountController(SignInManager<IdentityUser> sm, UserManager<IdentityUser> um)
        {
            _signInManager = sm;
            _userManager = um;
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var result = await _signInManager.PasswordSignInAsync(vm.Username, vm.Password, false, false);
            if (result.Succeeded)
            {
                var user = await _userManager.FindByNameAsync(vm.Username);
                var roles = await _userManager.GetRolesAsync(user);
                if (roles.Contains("Admin"))
                    return RedirectToAction("AdminDashboard", "Home");
                return RedirectToAction("UserProfile", "Home");
            }
            ModelState.AddModelError("", "Invalid login attempt");
            return View(vm);
        }
    }
}
