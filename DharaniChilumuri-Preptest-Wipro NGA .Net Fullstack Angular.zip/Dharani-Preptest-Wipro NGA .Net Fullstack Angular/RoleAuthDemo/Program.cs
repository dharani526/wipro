using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using RoleAuthDemo.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<ApplicationDbContext>(o => o.UseInMemoryDatabase("AuthDemo"));
builder.Services.AddIdentity<IdentityUser, IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}"
);

using (var scope = app.Services.CreateScope())
{
    var rm = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
    var um = scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();

    async Task Seed()
    {
        if (!await rm.RoleExistsAsync("Admin")) await rm.CreateAsync(new IdentityRole("Admin"));
        if (!await rm.RoleExistsAsync("User")) await rm.CreateAsync(new IdentityRole("User"));

        var admin = await um.FindByNameAsync("admin");
        if (admin == null)
        {
            admin = new IdentityUser { UserName = "admin" };
            await um.CreateAsync(admin, "Admin@123");
            await um.AddToRoleAsync(admin, "Admin");
        }

        var user1 = await um.FindByNameAsync("user1");
        if (user1 == null)
        {
            user1 = new IdentityUser { UserName = "user1" };
            await um.CreateAsync(user1, "User@123");
            await um.AddToRoleAsync(user1, "User");
        }
    }
    Seed().GetAwaiter().GetResult();
}

app.Run();
