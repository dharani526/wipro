﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("This is the entry point of the program");
        Employee e = new Employee();
        e.Input();
        e.Display();
    }
}
