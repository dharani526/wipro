using UserManagement.Services;
using Xunit;

namespace UserManagement.Tests;

public class CryptoTests
{
    [Fact]
    public void HashPassword_Works()
    {
        string hash1 = CryptoService.HashPassword("password");
        string hash2 = CryptoService.HashPassword("password");
        Assert.Equal(hash1, hash2);
    }

    [Fact]
    public void EncryptDecrypt_Works()
    {
        string original = "secret";
        string encrypted = CryptoService.EncryptString(original);
        string decrypted = CryptoService.DecryptString(encrypted);
        Assert.Equal(original, decrypted);
    }
}
