using UserManagement.Models;
using UserManagement.Services;
using Xunit;

namespace UserManagement.Tests;

public class AuthTests
{
    [Fact]
    public void User_Can_Register_And_Authenticate()
    {
        UserStore.Clear();
        User user = new User();
        user.Register("testpass", "info");
        Assert.True(user.Authenticate("testpass"));
    }
}
