﻿using UserManagement.Services;
using System.IO;
using Xunit;

namespace UserManagement.Tests;

public class LoggingTests
{
    private string logFile => Path.Combine(AppContext.BaseDirectory, "logs.txt");

    [Fact]
    public void Logs_File_Is_Created()
    {
        if (File.Exists(logFile)) File.Delete(logFile);
        LogConfig.Log("Test log");
        Assert.True(File.Exists(logFile));
    }

    [Fact]
    public void Logs_Content_Is_Written()
    {
        if (File.Exists(logFile)) File.Delete(logFile);
        LogConfig.Log("Test log content");
        string content = File.ReadAllText(logFile);
        Assert.Contains("Test log content", content);
    }
}
