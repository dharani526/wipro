using UserManagement.Services; 
namespace UserManagement.Models;

public class User
{
    public string Username { get; set; } = "default";
    public string HashedPassword { get; set; }
    public string EncryptedDetails { get; set; }

    public void Register(string password, string sensitiveDetails)
    {
        HashedPassword = CryptoService.HashPassword(password);
        EncryptedDetails = CryptoService.EncryptString(sensitiveDetails);
        UserStore.Add(this);
        LogConfig.Log("User registered.");
    }

    public bool Authenticate(string password)
    {
        return HashedPassword == CryptoService.HashPassword(password);
    }
}
