namespace UserManagement.Services;

public static class LogConfig
{
    private static readonly string LogFilePath = Path.Combine(AppContext.BaseDirectory, "logs.txt");

    public static void Log(string message)
    {
        File.AppendAllText(LogFilePath, $"{DateTime.Now}: {message}{Environment.NewLine}");
    }
}
