using System.Security.Cryptography;
using System.Text;

namespace UserManagement.Services;

public static class CryptoService
{
    public static string HashPassword(string password)
    {
        using SHA256 sha = SHA256.Create();
        byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(bytes);
    }

    public static string EncryptString(string plainText)
    {
        byte[] data = Encoding.UTF8.GetBytes(plainText);
        return Convert.ToBase64String(data);
    }

    public static string DecryptString(string cipherText)
    {
        byte[] data = Convert.FromBase64String(cipherText);
        return Encoding.UTF8.GetString(data);
    }
}
