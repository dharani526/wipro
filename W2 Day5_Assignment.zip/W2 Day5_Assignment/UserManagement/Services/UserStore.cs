using UserManagement.Models;

namespace UserManagement.Services;

public static class UserStore
{
    public static List<User> Users { get; set; } = new List<User>();

    public static void Add(User user) => Users.Add(user);

    public static void Clear() => Users.Clear();
}
