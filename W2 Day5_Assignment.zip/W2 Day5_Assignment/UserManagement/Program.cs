﻿using UserManagement.Models;
using UserManagement.Services;

User user = new User();
user.Register("password123", "Sensitive Info");

Console.WriteLine("User Registered.");
