const button = document.getElementById("fetchUserBtn");
const userCard = document.getElementById("userCard");
const userPic = document.getElementById("userPic");
const userName = document.getElementById("userName");
const userEmail = document.getElementById("userEmail");

button.addEventListener("click", () => {
    fetch("https://randomuser.me/api/")
        .then(response => response.json())
        .then(data => {
            const user = data.results[0];
            const fullName = `${user.name.title} ${user.name.first} ${user.name.last}`;
            userPic.src = user.picture.large;
            userName.textContent = fullName;
            userEmail.textContent = user.email;
            userCard.style.display = "block";
        })
        .catch(error => {
            alert("Failed to fetch user. Please try again.");
            console.error(error);
        });
});
