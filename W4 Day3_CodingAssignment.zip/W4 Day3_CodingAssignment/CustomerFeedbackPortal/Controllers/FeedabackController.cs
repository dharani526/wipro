using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using CustomerFeedbackPortal.Models;
using System.Collections.Generic;

namespace CustomerFeedbackPortal.Controllers
{
    public class FeedbackController : Controller
    {
       
        private static List<CustomerModel> FeedbackList = new List<CustomerModel>();

        public IActionResult GiveFeedback()
        {
            ViewBag.Ratings = new SelectList(new List<int> { 1, 2, 3, 4, 5 });
            return View();
        }

        [HttpPost]
        public IActionResult GiveFeedback(CustomerModel model)
        {
            if (ModelState.IsValid)
            {
                FeedbackList.Add(model); 
                return RedirectToAction("ViewFeedback");
            }

            ViewBag.Ratings = new SelectList(new List<int> { 1, 2, 3, 4, 5 });
            return View(model);
        }
        public IActionResult ViewFeedback()
        {
            return View(FeedbackList);
        }
    }
}
