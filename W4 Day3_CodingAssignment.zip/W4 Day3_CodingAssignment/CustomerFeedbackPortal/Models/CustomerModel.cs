using System.ComponentModel.DataAnnotations;

namespace CustomerFeedbackPortal.Models
{
    public class CustomerModel
    {
        [Required]
        public string Name { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Range(1, 5)]
        public int Rating { get; set; }

        public string Comments { get; set; }
    }
}
