using Microsoft.AspNetCore.Razor.TagHelpers;

namespace CustomerFeedbackPortal.TagHelpers
{
    [HtmlTargetElement("rating-stars")]
    public class RatingTagHelper : TagHelper
    {
        public int Rating { get; set; } = 0; 

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.Attributes.SetAttribute("class", "rating-stars");

            var content = "";
            for (int i = 1; i <= 5; i++)
            {
                content += i <= Rating ? "★" : "☆"; 
            }

            output.Content.SetHtmlContent(content);
        }
    }
}
