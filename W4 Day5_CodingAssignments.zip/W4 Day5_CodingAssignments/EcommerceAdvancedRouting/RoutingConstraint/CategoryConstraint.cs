using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using System.Collections.Generic;

namespace ECommerceAdvancedRouting.RoutingConstraints
{
    public class CategoryConstraint : IRouteConstraint
    {
        private readonly List<string> _validCategories = new() { "Electronics", "Books", "Clothing" };

        public bool Match(HttpContext httpContext, IRouter route, string routeKey,
                          RouteValueDictionary values, RouteDirection routeDirection)
        {
            if (!values.ContainsKey(routeKey)) return false;
            var category = values[routeKey]?.ToString();
            return category != null && _validCategories.Contains(category);
        }
    }
}
