using Microsoft.AspNetCore.Mvc;

namespace ECommerceAdvancedRouting.Controllers
{
    public class CartController : Controller
    {
        [Route("Cart")]
        public IActionResult Index()
        {
            return View();
        }
    }
}
