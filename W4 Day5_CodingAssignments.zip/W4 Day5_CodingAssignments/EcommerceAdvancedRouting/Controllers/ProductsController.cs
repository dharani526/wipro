using Microsoft.AspNetCore.Mvc;
using ECommerceAdvancedRouting.Models;
using System.Collections.Generic;

namespace ECommerceAdvancedRouting.Controllers
{
    public class ProductsController : Controller
    {
        private static List<ProductModel> Products = new()
        {
            new ProductModel{ Id=1, Name="Laptop", Category="Electronics", Price=1200 },
            new ProductModel{ Id=2, Name="T-Shirt", Category="Clothing", Price=20 },
            new ProductModel{ Id=3, Name="C# Book", Category="Books", Price=35 }
        };

        [Route("Products/{category}/{id}")]
        public IActionResult Details(string category, int id)
        {
            var product = Products.Find(p => p.Category == category && p.Id == id);
            if (product == null) return NotFound();
            return View(product);
        }

        [Route("Products/Filter/{category:category}/{priceRange}")]
        public IActionResult Filter(string category, string priceRange)
        {
            string[] parts = priceRange.Split("-");
            decimal min = decimal.Parse(parts[0]);
            decimal max = decimal.Parse(parts[1]);

            var filteredProducts = Products.FindAll(p => p.Category == category && p.Price >= min && p.Price <= max);
            return View(filteredProducts);
        }
    }
}
