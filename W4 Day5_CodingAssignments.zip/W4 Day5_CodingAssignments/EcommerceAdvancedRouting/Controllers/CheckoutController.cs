using Microsoft.AspNetCore.Mvc;

namespace ECommerceAdvancedRouting.Controllers
{
    public class CheckoutController : Controller
    {
        [Route("Checkout")]
        public IActionResult Index()
        {
            bool isLoggedIn = false; 
            if (!isLoggedIn)
                return RedirectToAction("Index", "Cart"); 
            return View();
        }
    }
}
