using Microsoft.AspNetCore.Mvc;
using System;

namespace AdvancedRoutingDemo.Controllers
{
    public class OrdersController : Controller
    {
        [Route("Orders/{orderId:guid}")]
        public IActionResult OrderDetails(Guid orderId)
        {
            ViewBag.OrderId = orderId;
            return View();
        }
    }
}
