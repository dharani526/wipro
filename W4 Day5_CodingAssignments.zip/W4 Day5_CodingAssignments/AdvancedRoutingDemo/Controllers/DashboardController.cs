using Microsoft.AspNetCore.Mvc;

namespace AdvancedRoutingDemo.Controllers
{
    public class DashboardController : Controller
    {
        [Route("Dashboard")]
        public IActionResult Index()
        {
            var role = "Admin"; // Replace with real user role logic

            if (role == "Admin")
                return RedirectToAction("AdminDashboard");
            else
                return RedirectToAction("UserDashboard");
        }

        public IActionResult AdminDashboard() => View();
        public IActionResult UserDashboard() => View();
    }
}
