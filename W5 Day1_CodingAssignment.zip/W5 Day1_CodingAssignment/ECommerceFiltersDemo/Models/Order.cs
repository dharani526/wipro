namespace ECommerceFiltersDemo.Models
{
    public class Order
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public string OrderedBy { get; set; }
    }
}
