namespace ECommerceFiltersDemo.Models
{
    public class User
    {
        public string Username { get; set; }
        public bool IsLoggedIn { get; set; }
    }
}
