using System.Diagnostics;

namespace ECommerceFiltersDemo.Services
{
    public class LoggingService : ILoggingService
    {
        public void Log(string message)
        {
            Debug.WriteLine($"[LOG] {message}");
        }
    }
}
