namespace ECommerceFiltersDemo.Services
{
    public interface IAuthService
    {
        bool IsUserLoggedIn();
    }
}
