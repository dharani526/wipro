namespace ECommerceFiltersDemo.Services
{
    public class AuthService : IAuthService
    {
        // For demo: pretend the user is logged out
        private bool _isLoggedIn = false;

        public bool IsUserLoggedIn() => _isLoggedIn;

        public void Login() => _isLoggedIn = true;
        public void Logout() => _isLoggedIn = false;
    }
}
