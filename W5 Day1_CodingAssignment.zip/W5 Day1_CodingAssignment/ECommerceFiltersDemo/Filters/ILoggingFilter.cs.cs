using Microsoft.AspNetCore.Mvc.Filters;
using ECommerceFiltersDemo.Services;

namespace ECommerceFiltersDemo.Filters
{
    public class LoggingFilter : IActionFilter
    {
        private readonly ILoggingService _logger;

        public LoggingFilter(ILoggingService logger)
        {
            _logger = logger;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            _logger.Log($"[Request] Path: {context.HttpContext.Request.Path}");
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            _logger.Log($"[Response] Status: {context.HttpContext.Response.StatusCode}");
        }
    }
}
