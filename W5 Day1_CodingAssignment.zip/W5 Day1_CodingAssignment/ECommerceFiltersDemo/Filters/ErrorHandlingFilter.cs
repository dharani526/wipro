using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using ECommerceFiltersDemo.Services;

namespace ECommerceFiltersDemo.Filters
{
    public class ErrorHandlingFilter : IExceptionFilter
    {
        private readonly ILoggingService _logger;

        public ErrorHandlingFilter(ILoggingService logger)
        {
            _logger = logger;
        }

        public void OnException(ExceptionContext context)
        {
            _logger.Log($"[Error] {context.Exception.Message}");
            context.Result = new ViewResult { ViewName = "Error" };
            context.ExceptionHandled = true;
        }
    }
}
