using Microsoft.AspNetCore.Mvc;

namespace ECommerceFiltersDemo.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Login()
        {
            return Content("Please log in to continue.");
        }
    }
}
