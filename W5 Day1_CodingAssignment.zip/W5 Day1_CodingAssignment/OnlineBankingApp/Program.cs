using OnlineBankingApp.Services;
using OnlineBankingApp.Filters;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add<RequestLoggingFilter>();
    options.Filters.Add<GlobalExceptionFilter>();
});

builder.Services.AddSingleton<IAuthService, AuthService>();
builder.Services.AddSingleton<IAuditLogger, AuditLogger>();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession();

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.MapDefaultControllerRoute();

app.Run();
