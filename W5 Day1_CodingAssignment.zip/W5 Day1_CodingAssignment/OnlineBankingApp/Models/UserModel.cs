namespace OnlineBankingApp.Models
{
    public class User
    {
        public string UserId { get; set; }
        public string Username { get; set; }
        public string Role { get; set; } 
    }

    public class Transaction
    {
        public string TransactionId { get; set; }
        public string UserId { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
    }
}
