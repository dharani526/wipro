namespace OnlineBankingApp.Services;

public interface IAuditLogger
{
    void Log(string message);
}
