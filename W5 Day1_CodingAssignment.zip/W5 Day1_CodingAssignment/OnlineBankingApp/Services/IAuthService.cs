namespace OnlineBankingApp.Services;

public interface IAuthService
{
    bool IsLoggedIn(HttpContext context);
    string? GetUserRole(HttpContext context);
    void Login(HttpContext context, string username, string role);
    void Logout(HttpContext context);
}
