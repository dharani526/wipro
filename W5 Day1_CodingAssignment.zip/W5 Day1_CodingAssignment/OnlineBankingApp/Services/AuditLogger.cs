namespace OnlineBankingApp.Services;

public class AuditLogger : IAuditLogger
{
    public void Log(string message)
    {
        Console.WriteLine($"[Audit] {DateTime.Now}: {message}");
    }
}
