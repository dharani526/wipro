namespace OnlineBankingApp.Services;

public class AuthService : IAuthService
{
    private const string SessionUserKey = "User";
    private const string SessionRoleKey = "Role";

    public bool IsLoggedIn(HttpContext context) =>
        !string.IsNullOrEmpty(context.Session.GetString(SessionUserKey));

    public string? GetUserRole(HttpContext context) =>
        context.Session.GetString(SessionRoleKey);

    public void Login(HttpContext context, string username, string role)
    {
        context.Session.SetString(SessionUserKey, username);
        context.Session.SetString(SessionRoleKey, role);
    }

    public void Logout(HttpContext context)
    {
        context.Session.Clear();
    }
}
