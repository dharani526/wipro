using Microsoft.AspNetCore.Mvc.Filters;
using OnlineBankingApp.Services;

namespace OnlineBankingApp.Filters;

public class RequestLoggingFilter : IActionFilter
{
    private readonly IAuditLogger _logger;
    public RequestLoggingFilter(IAuditLogger logger) => _logger = logger;

    public void OnActionExecuting(ActionExecutingContext context)
    {
        var req = context.HttpContext.Request;
        _logger.Log($"Request: {req.Method} {req.Path}");
    }

    public void OnActionExecuted(ActionExecutedContext context)
    {
        var res = context.HttpContext.Response;
        _logger.Log($"Response: {res.StatusCode}");
    }
}
