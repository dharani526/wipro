using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using OnlineBankingApp.Services;

namespace OnlineBankingApp.Filters;

public class RoleFilter : IAuthorizationFilter
{
    private readonly IAuthService _authService;
    private readonly string _role;
    public RoleFilter(IAuthService authService, string role)
    {
        _authService = authService;
        _role = role;
    }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var role = _authService.GetUserRole(context.HttpContext);
        if (role != _role)
        {
            context.Result = new ForbidResult();
        }
    }
}
