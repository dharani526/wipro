using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using OnlineBankingApp.Services;

namespace OnlineBankingApp.Filters;

public class GlobalExceptionFilter : IExceptionFilter
{
    private readonly IAuditLogger _logger;
    public GlobalExceptionFilter(IAuditLogger logger) => _logger = logger;

    public void OnException(ExceptionContext context)
    {
        _logger.Log($"Exception: {context.Exception.Message}");
        context.Result = new ViewResult { ViewName = "~/Views/Shared/Error.cshtml" };
        context.ExceptionHandled = true;
    }
}
