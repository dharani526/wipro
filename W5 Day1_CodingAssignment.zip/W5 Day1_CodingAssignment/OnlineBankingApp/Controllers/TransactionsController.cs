using Microsoft.AspNetCore.Mvc;
using OnlineBankingApp.Filters;

namespace OnlineBankingApp.Controllers;

[TypeFilter(typeof(AuthFilter))]
public class TransactionsController : Controller
{
    public IActionResult Index() => View();

    [HttpPost]
    public IActionResult Transfer(decimal amount)
    {
        if (amount <= 0) throw new Exception("Invalid amount!");
        ViewBag.Message = $"Transferred {amount}";
        return View("Index");
    }
}
