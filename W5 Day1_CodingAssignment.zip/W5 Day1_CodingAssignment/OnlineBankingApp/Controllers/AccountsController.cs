using Microsoft.AspNetCore.Mvc;
using OnlineBankingApp.Filters;

namespace OnlineBankingApp.Controllers;

[TypeFilter(typeof(AuthFilter))]
public class AccountsController : Controller
{
    public IActionResult Dashboard() => View();

    [TypeFilter(typeof(RoleFilter), Arguments = new object[] { "Admin" })]
    public IActionResult AllUsers() => View();
}
