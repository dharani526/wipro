using Microsoft.AspNetCore.Mvc;
using OnlineBankingApp.Services;

namespace OnlineBankingApp.Controllers;

public class AccountController : Controller
{
    private readonly IAuthService _authService;
    public AccountController(IAuthService authService) => _authService = authService;

    public IActionResult Login() => View();

    [HttpPost]
    public IActionResult Login(string username, string role)
    {
        _authService.Login(HttpContext, username, role);
        return RedirectToAction("Dashboard", "Accounts");
    }

    public IActionResult Logout()
    {
        _authService.Logout(HttpContext);
        return RedirectToAction("Login");
    }
}
