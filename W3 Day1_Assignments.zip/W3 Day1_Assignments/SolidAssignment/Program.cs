﻿using System;
using System.IO;

namespace SolidAssignment
{
 
    // ISP 
    public interface IReport
    {
        string Title { get; }
    }

    public interface IPrintableReport : IReport
    {
        string GenerateContent();
    }

    // LSP
    public class SalesReport : IPrintableReport
    {
        public string Title => "Sales Report";
        public string GenerateContent() => "Sales data...";
    }

    public class FinanceReport : IPrintableReport
    {
        public string Title => "Finance Report";
        public string GenerateContent() => "Finance data...";
    }

    // OCP
    public interface IReportFormatter
    {
        string Format(IPrintableReport report);
    }

    public class PdfReportFormatter : IReportFormatter
    {
        public string Format(IPrintableReport report)
            => $"[PDF] {report.Title}\n{report.GenerateContent()}";
    }

    public class ExcelReportFormatter : IReportFormatter
    {
        public string Format(IPrintableReport report)
            => $"[Excel] {report.Title}\n{report.GenerateContent()}";
    }

    // SRP
    public class ReportGenerator
    {
        private readonly IReportFormatter _formatter;
        public ReportGenerator(IReportFormatter formatter) { _formatter = formatter; }
        public string Generate(IPrintableReport report) => _formatter.Format(report);
    }

    public class ReportSaver
    {
        public void Save(string reportData, string filePath)
        {
            File.WriteAllText(filePath, reportData);
            Console.WriteLine($"Report saved to {filePath}");
        }
    }

    // DIP
    public class ReportService
    {
        private readonly ReportGenerator _generator;
        private readonly ReportSaver _saver;

        public ReportService(ReportGenerator generator, ReportSaver saver)
        {
            _generator = generator;
            _saver = saver;
        }

        public void CreateAndSaveReport(IPrintableReport report, string filePath)
        {
            string data = _generator.Generate(report);
            _saver.Save(data, filePath);
        }
    }

    // class Program
    // {
    //     static void Main(string[] args)
    //     {
    //         IPrintableReport report = new SalesReport();
    //         IReportFormatter formatter = new PdfReportFormatter();

    //         var generator = new ReportGenerator(formatter);
    //         var saver = new ReportSaver();
    //         var service = new ReportService(generator, saver);

    //         service.CreateAndSaveReport(report, "report.pdf");
    //     }
    // }
}
