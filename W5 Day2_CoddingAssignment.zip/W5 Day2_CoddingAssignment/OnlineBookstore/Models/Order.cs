public class Order
{
    public int Id { get; set; }
    public string UserId { get; set; }
    public DateTime OrderDate { get; set; } = DateTime.Now;
    public List<CartItem> Items { get; set; } = new();
}
