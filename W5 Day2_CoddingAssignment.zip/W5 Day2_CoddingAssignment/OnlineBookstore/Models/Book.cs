using System.ComponentModel.DataAnnotations;

namespace BookStoreApp.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Author { get; set; }

        [RegularExpression(@"\d{13}", ErrorMessage = "ISBN must be 13 digits")]
        public string ISBN { get; set; }

        [Range(1, 5000)]
        public decimal Price { get; set; }
    }
}
