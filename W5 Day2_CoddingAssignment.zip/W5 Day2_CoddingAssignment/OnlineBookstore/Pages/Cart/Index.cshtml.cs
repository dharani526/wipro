using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using System.Text.Json;
using BookStoreApp.Models;
using System.Collections.Generic;

namespace BookStoreApp.Pages.Cart
{
    public class IndexModel : PageModel
    {
        public List<CartItem> Cart { get; set; } = new();

        public void OnGet()
        {
            var cartJson = HttpContext.Session.GetString("Cart");
            if (cartJson != null)
                Cart = JsonSerializer.Deserialize<List<CartItem>>(cartJson);
        }
    }
}
