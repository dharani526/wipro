using Microsoft.AspNetCore.Mvc;
using BookStoreApp.Data;
using System.Linq;

namespace BookStoreApp.Controllers
{
    public class BooksController : Controller
    {
        private readonly ApplicationDbContext _context;
        public BooksController(ApplicationDbContext context) => _context = context;

        public IActionResult Index() => View(_context.Books.ToList());

        public IActionResult Details(int id)
        {
            var book = _context.Books.Find(id);
            if (book == null) return NotFound();
            return View(book);
        }
    }
}
