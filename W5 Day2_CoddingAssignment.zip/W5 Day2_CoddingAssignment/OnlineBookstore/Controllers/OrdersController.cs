using Microsoft.AspNetCore.Mvc;

namespace BookStoreApp.Controllers
{
    public class OrdersController : Controller
    {
        public IActionResult Checkout()
        {
            return View();
        }
    }
}
